import request from './axios'
import type { TestCase } from '@/types'

// 获取所有用例 - 后端直接返回数组
export const getCases = () => {
  return request.get<TestCase[]>('/cases')
}

// 创建用例 - 与后端匹配
export const createCase = (data: {
  project: string
  nlp: string
  aiConfig?: any
}) => {
  return request.post<TestCase>('/cases', data)
}

// 更新用例 - 后端不支持，保留接口
export const updateCase = (id: string, data: Partial<TestCase>) => {
  return request.put<TestCase>(`/cases/${id}`, data)
}

// 删除用例
export const deleteCase = (id: string) => {
  return request.delete<{ success: boolean }>(`/cases/${encodeURIComponent(id)}`)
}

// 执行用例 - 后端使用 /api/update-and-execute
export const executeCase = (id: string, aiConfig?: any, customYaml?: string) => {
  return request.post<any>('/update-and-execute', {
    caseId: id,
    customYaml: customYaml || '',
    aiConfig: aiConfig || {},
    browserHeadless: aiConfig?.browserMode === 'headless'
  })
}

// 获取单个用例
export const getCase = (id: string) => {
  return request.get<TestCase>(`/cases/${encodeURIComponent(id)}`)
}
