import request from './axios'
import type { ApiResponse } from '@/types'

// 获取所有项目 - 后端直接返回字符串数组
export const getProjects = () => {
  return request.get<string[]>('/projects')
}

// 创建项目
export const createProject = (data: { project: string }) => {
  return request.post<ApiResponse<any>>('/projects', data)
}

// 删除项目 - 后端使用项目名称
export const deleteProject = (name: string) => {
  return request.delete<ApiResponse>(`/projects/${encodeURIComponent(name)}`)
}
