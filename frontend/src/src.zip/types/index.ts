// 项目类型
export interface Project {
  id?: number
  name: string
  description?: string
}

// 测试用例类型 - 与后端匹配
export interface TestCase {
  id?: string
  project?: string
  nlp?: string
  status?: 'pending' | 'running' | 'success' | 'failed'
  createdAt?: string
  executedAt?: string
}

// 执行结果统计
export interface ExecutionStats {
  totalProjects: number
  totalCases: number
  successCount: number
  failedCount: number
}

// 每日统计
export interface DailyStats {
  date: string
  success: number
  failed: number
}

// 项目近7日数据
export interface ProjectStats {
  project_id: number
  project_name: string
  daily_stats: DailyStats[]
  total: number
  success_rate: number
  min_success_rate: number
  max_success_rate: number
  avg_success_rate: number
}

// 报告类型
export interface Report {
  id?: string
  case_id?: string
  case_name: string
  project_name: string
  status: 'success' | 'failed' | 'running'
  logs?: string
  created_at?: string
  duration?: number
}

// AI配置
export interface AIConfig {
  baseUrl: string
  apiKey: string
  modelName: string
  modelFamily: string
  browserMode: 'headless' | 'headful'
}

// Flow步骤类型
export type FlowStepType = 'ai' | 'sleep' | 'aiAssert' | 'custom'

// Flow步骤
export interface FlowStep {
  type: FlowStepType
  instruction?: string
  duration?: number
  assertion?: string
  code?: string
  index?: number
}

// YAML配置
export interface YamlConfig {
  name: string
  type: 'web' | 'task' | 'flow'
  url?: string
  flow?: FlowStep[]
  task?: {
    nlp: string
  }
}

// API响应类型
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  message?: string
  error?: string
}

// 路由元信息
export interface RouteMeta {
  title: string
  icon?: string
  requiresAuth?: boolean
}
